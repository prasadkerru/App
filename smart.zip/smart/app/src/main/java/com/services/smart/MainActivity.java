package com.services.smart;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        HashMap<String, String> HashMap = new HashMap<String, String>();

        //cITY,DISTRICT,ph,tURBI,sodium,dissolved oxygen,BOD,Electrical Conductivity
        HashMap.put("Rajasthan", "BUNDI,3.2,490,6.6,600");
        HashMap.put("Rajasthan", "DUNGARPUR,7,530,0.3,3,7.4,620");
        HashMap.put("Rajasthan", "UDAIPUR,7.1,520,0.27,2.8,1.1,360");
        HashMap.put("Rajasthan", "AJMER,6,460,0.48,7,2.9,560 ");
        HashMap.put("Rajasthan", "DHOLPUR,2,140,0.9,7.1,3.1,1210");
        HashMap.put("Rajasthan", "SIROHI,5.3,74,0.5,6,3,410");
        HashMap.put("Rajasthan", "GANGANAGAR,0.9,16,0.54,2,5.3,280");
        HashMap.put("Rajasthan", "HANUMANGARH,0.5,2.0.5,5.3,1.4,250");
        HashMap.put("Rajasthan", "RAJSAMAND,5.8,8,2.95,0.9,0.7,150");
        HashMap.put("Rajasthan", "BANSWARA,3.6,3,0.58,5.8,0.8,220");
        HashMap.put("Rajasthan", "PALI,4.8,3.2,0.57,5.6,2.3,530");
        HashMap.put("Rajasthan", "TONK,6.5,3.7,0.61,6.5,2.8,530");
        HashMap.put("Rajasthan", "JAIPUR,5.5,4.4,0.60,5.25,2.8,500");
        HashMap.put("Rajasthan", "BHILWARA,6,6.3,0.34,4.8,1.4,150");
        HashMap.put("Rajasthan", "UDAIPUR,5.7,3.4,1.7,6,5.3,280");
        HashMap.put("Punjab", "JALANDHAR,6.9,34,0.33,24,1.6,287");
        HashMap.put("Punjab", "KAPURTHALA,7.6,38,0.08,7.6,8,254");
        HashMap.put("Punjab", "LUDHIANA,7.1,25,0.1,1,10,320");
        HashMap.put("Punjab", "GURDASPUR,7.2,9.2,0.4,4.8,6,950");
        HashMap.put("Punjab", "MOHALI,7.3,10,0.17,7.1,4.8,1031");
        HashMap.put("Punjab", "FEROZPUR,8.1,15,0.54,7.6,2.8,1113");
        HashMap.put("Punjab", "PATIALA,8,96,0.3,8.4,1.1,1205");
        HashMap.put("Punjab", "NAVANSHAHR,7.6,15,0.17,6.4,1.2,280");
        HashMap.put("Punjab", "MANSA,7.9,14,0.09,4.1,1,316");
        HashMap.put("Punjab", "SANGRUR,7.2,42,0.16,4.7,8.2,316");
        HashMap.put("Punjab", "AMRITSAR,7.9,30,0.37,6.22.4,218");
        HashMap.put("Andhra Pradesh", "WARANGAL,7.6,5,0.2,3.5,2.1,680");
        HashMap.put("Andhra Pradesh", "KURNOOL,7.3,6,3.73,3.2,2.6,1390");
        HashMap.put("Andhra Pradesh", "KRISHNA,7.2,5,14.07,1.2,2.2,820");
        HashMap.put("Andhra Pradesh", "WEST GODAVARI,7.1,12.8,1.27,0.1,2.2,920");
        HashMap.put("Andhra Pradesh", "EAST GODAVARI,7.2,6,7.21,1.7,1.8,225");
        HashMap.put("Andhra Pradesh", "ANANTAPUR,7,10,1.34,5.7,1.6,790");
        HashMap.put("Andhra Pradesh", "CUDDAPAH,7.3,6,0.48,2.9,2.1,344");
        HashMap.put("Andhra Pradesh", "VIZIANAGARAM,7,48,0.45,6.8,1.7,299");
        HashMap.put("Andhra Pradesh", "GUNTUR,7.1,22,0.16,7.3,2.4,1188");
        HashMap.put("Andhra Pradesh", "MAHABUBNAGAR,6.8,48,0.56,1.1,2.1,280");
        HashMap.put("Andhra Pradesh", "RANGAREDDY,7,6,0.58,4.8,2,867");
        HashMap.put("Andhra Pradesh", "NELLORE,7.2,6,0.58,7.3,1.2,679");
        HashMap.put("Andhra Pradesh", "VISAKHAPATNAM,7,4,0.37,6.8,2.1,1274");
        HashMap.put("Andhra Pradesh", "KHAMMAM,7.7,5,0.46,1.9,2,874");
        HashMap.put("karnataka","Belgaum,2,7,7.9,2.4,2,942");
        HashMap.put("karnataka","Banglore,4.8,5,6.8,8,2,164");
        HashMap.put("karnataka","Mandya,2.8,0,3,7.8,14,2,63");
        HashMap.put("karnataka","Shimonga,1.2,0.3,7.7,2.5,1,510");
        HashMap.put("karnataka","Bangalkot,1.2,6.4,7.7,25,1,268");
        HashMap.put("karnataka","Maysore,1.4,7,7.3,2.9,0.7");
        HashMap.put("karnataka","Timkur,2,3.7,8.9,2,2.8,150");
        HashMap.put("karnataka","Kolar,2,7,7.9,2.4,2.2,260");
        HashMap.put("karnataka","Haveri,6,1.9,6.8,2.0,2,940");
        HashMap.put("Meghalaya","East Jinita hills,1.5,7.4,0.32,3.7,1.3,818");
        HashMap.put("Meghalaya","RI bhoi,1.6,7.3,0.35,5.2,1.5,588");
        HashMap.put("Meghalaya","East Garo hills,1.4,7.4,0.6,3.6,3,1226");
        HashMap.put("Meghalaya","East kaira hills,1.5,7.5,1.02,5.0,2.5,640");
        HashMap.put("Odisha","Anugul,1.1,1.9,6.8,40,1.2,340");
        HashMap.put("Odisha","Sambalpur,1.2,2.4,7.7,60,2.8,548");
        HashMap.put("Odisha","Sonapur,1.4,2.7,7.2,29,1.3,217");
        HashMap.put("Odisha","cuttack,1.2,3.4,7.3,40,1.2,159");
        HashMap.put("Odisha","Ganjam,1.7,3.2,7.1,60,4.9,259");
        HashMap.put("Odisha","Mayubhruj,1.4,2.7,6.9,40,1.3,164");
        HashMap.put("Delhi","North west,5.2,2.7,7.9,0,0.8,191");
        HashMap.put("Delhi","south,4.7,1.3,7.6,0,1.1,134");
        HashMap.put("Gujarat","valsad,0.4,1.7,7.7,0.3,1.5,153");
        HashMap.put("Gujarat","kedha,0.7,2.3,7.9,0.5,1.1,269");
        HashMap.put("Gujarat","Ahamedhbad,0.9,1.4,7.2,0.6,1.8,203");
        HashMap.put("Gujarat","Dohad,0.4,2.7,7.5,0.7,1.3,178");
        HashMap.put("Gujarat","surat,2.9,4.2,7.3,1.2,1.6,241");
        HashMap.put("Gujarat","daman,0.7,3.3,7.7,1.7,0.9,164");

    }
};






